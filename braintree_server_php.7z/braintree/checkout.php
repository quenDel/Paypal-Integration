<?php
header('Content-Type: application/json');

require_once("braintree_init.php");
require_once 'lib/Braintree.php';

$nonce = $_POST['nonce'];
$amount = $_POST['amount'];

$result = $gateway->transaction()->sale([
  'amount' => $amount,
  'orderId' => 'order-id52452',
  'merchantAccountId' => 'quendel',
  'paymentMethodNonce' => $nonce,

 /* 'customer' => [
    'firstName' => 'Drew',
    'lastName' => 'Smith',
    'company' => 'Braintree',
    'phone' => '312-555-1234',
    'fax' => '312-555-1235',
    'website' => 'http://www.example.com',
    'email' => 'drew@example.com'
  ],
  'billing' => [
    'firstName' => 'Paul',
    'lastName' => 'Smith',
    'company' => 'Braintree',
    'streetAddress' => '1 E Main St',
    'extendedAddress' => 'Suite 403',
    'locality' => 'Chicago',
    'region' => 'IL',
    'postalCode' => '60622',
    'countryCodeAlpha2' => 'US'
  ],
  'shipping' => [
    'firstName' => 'Jen',
    'lastName' => 'Smith',
    'company' => 'Braintree',
    'streetAddress' => '1 E 1st St',
    'extendedAddress' => 'Suite 403',
    'locality' => 'Bartlett',
    'region' => 'IL',
    'postalCode' => '60103',
    'countryCodeAlpha2' => 'US'
  ],*/
  'options' => [
    'submitForSettlement' => true
  ]

]);



if ($result) {
	echo json_encode(array("result" => $result, "status" => true));
}else{
	echo json_encode(array("result" => $result, "status" => false));
}

?>