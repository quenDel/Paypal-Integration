<?php
header('Content-Type: application/json');
require_once("braintree_init.php");
require_once("lib/Braintree.php");

$clientToken = $gateway->clientToken()->generate();

if ($clientToken) {
	echo json_encode(array("clientToken" => $clientToken, "status" => true));
}else{
	echo json_encode(array("clientToken" => "", "status" => false));
}
?>