<?php 
session_start();
require_once ("lib/autoload.php");

if(file_exists(__DIR__ . "/../.env")){

	$dotenv = new Dotenv\Dotenv(__DIR__ . "/../");
	$dotenv->load();
}


$gateway = new Braintree_Gateway([
  'environment' => 'sandbox',
  'merchantId' => 'w9cqw8z83y7mndcz',
  'publicKey' => 'q3s3hvk4sqcr7bv7',
  'privateKey' => '7cb07b1adc065c2c1062c0461c85770d'
]);

 ?>